﻿namespace WildFarm.Models.Interfaces
{
    public interface IFeline :IMammal
    {
        public string Breed { get; }
    }
}

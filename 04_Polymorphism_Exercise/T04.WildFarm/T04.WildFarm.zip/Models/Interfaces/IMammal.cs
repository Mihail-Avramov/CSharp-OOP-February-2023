﻿namespace WildFarm.Models.Interfaces
{
    public interface IMammal : IAnimal
    {
        public string LivingRegion { get; }
    }
}

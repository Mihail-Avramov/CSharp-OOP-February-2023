﻿namespace Zoo
{
    internal class Gorilla : Mammal
    {
        public Gorilla(string name) : base(name)
        {
        }
    }
}
